<footer class="footer">
    <div class="text-center p-3">
        © 2023 Copyright:
        <a class="text-body" href="{{ asset('index.php') }}">laravel.bakery</a>
    </div>
</footer>
