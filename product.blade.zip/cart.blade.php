@extends('layouts._layout')

@section('content')
    <main class="main">
        <div class="container-fluid">
            <div class="row mt-5 mb-5">
                <div class="col-12">
                    <h2 class="section-title text-center">
                        <span>Товары в корзине</span>
                    </h2>
                </div>
            </div>

            <div class="d-flex">
                <div class="card col-7 mb-5">
                    <div class="row">
                        <div class="cart">
                            <div class="row">
                                <div class="row main align-items-center">
                                    <div class="col-2 product-thumb"><img class="img-fluid" src="{{ asset('img/products/tort1.jpg') }}" alt=""></div>
                                    <div class="col">
                                        <div class="row text-muted">Торты</div>
                                        <div class="row">Ежик в тумане</div>
                                    </div>
                                    <div class="col">
                                        <a href="#"> - </a><a href="#" class="border">1</a><a href="#"> + </a>
                                    </div>
                                    <div class="col">100 ₽</div>
                                    <div class="col-1">
                                        <button class="btn btn-sm btn-danger"><i class="fa-solid fa-xmark"></i></button>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="row main align-items-center">
                                    <div class="col-2 product-thumb"><img class="img-fluid" src="{{ asset('img/products/bulochka3.jpg') }}" alt=""></div>
                                    <div class="col">
                                        <div class="row text-muted">Булочки</div>
                                        <div class="row">Булочка с маком</div>
                                    </div>
                                    <div class="col">
                                        <a href="#"> - </a><a href="#" class="border">1</a><a href="#"> + </a>
                                    </div>
                                    <div class="col">100 ₽</div>
                                    <div class="col-1">
                                        <button class="btn btn-sm  btn-danger"><i class="fa-solid fa-xmark"></i></button>
                                    </div>

                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="row main align-items-center">
                                    <div class="col-2 product-thumb"><img class="img-fluid" src="{{ asset('img/products/hachapuri.jpg') }}" alt=""></div>
                                    <div class="col">
                                        <div class="row text-muted">Пирожки</div>
                                        <div class="row">Хачапури</div>
                                    </div>
                                    <div class="col">
                                        <a href="#"> - </a><a href="#" class="border">1</a><a href="#"> + </a>
                                    </div>
                                    <div class="col">100 ₽</div>
                                    <div class="col-1">
                                        <button class="btn btn-sm  btn-danger"><i class="fa-solid fa-xmark"></i></button>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="row main align-items-center">
                                    <div class="col-2 product-thumb"><img class="img-fluid" src="{{ asset('img/products/bulochka4.jpg') }}" alt=""></div>
                                    <div class="col">
                                        <div class="row text-muted">Булочки</div>
                                        <div class="row">Булочка с вишней</div>
                                    </div>
                                    <div class="col">
                                        <a href="#"> - </a><a href="#" class="border">1</a><a href="#"> + </a>
                                    </div>
                                    <div class="col">100 ₽</div>
                                    <div class="col-1">
                                        <button class="btn btn-sm  btn-danger"><i class="fa-solid fa-xmark"></i></button>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="row main align-items-center">
                                    <div class="col-2 product-thumb"><img class="img-fluid" src="{{ asset('img/products/baton3.jpg') }}" alt=""></div>
                                    <div class="col">
                                        <div class="row text-muted">Хлеб</div>
                                        <div class="row">Батон новомосковский</div>
                                    </div>
                                    <div class="col">
                                        <a href="#"> - </a><a href="#" class="border">1</a><a href="#"> + </a>
                                    </div>
                                    <div class="col">100 ₽</div>
                                    <div class="col-1">
                                        <button class="btn btn-sm  btn-danger"><i class="fa-solid fa-xmark"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card col-4 ms-5 mb-5 ">
                    <div class="row">
                        <div class="row main align-items-center">
                            <h2 class="col">Ваша корзина</h2>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </main>
@endsection
